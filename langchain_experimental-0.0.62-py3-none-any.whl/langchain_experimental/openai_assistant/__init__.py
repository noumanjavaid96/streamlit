from langchain_experimental.openai_assistant.base import OpenAIAssistantRunnable

__all__ = ["OpenAIAssistantRunnable"]
