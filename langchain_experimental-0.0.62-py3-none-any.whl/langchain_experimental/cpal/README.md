# Causal program-aided language (CPAL) chain


see https://github.com/langchain-ai/langchain/pull/6255
